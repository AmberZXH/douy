<template>
  <div>Check</div>
  <el-row :gutter="20">
    <el-col :span="12" class="h-50">
      <el-form-item label="routing ID">
        <el-input v-model="routingId" class="w-200 m-2" size="large"/>
      </el-form-item>
    </el-col>
  </el-row>

<!--  <el-table :data="outwardList.outward" style="width: 100%" height="250">-->
<!--    <el-table-column fixed prop="price.amount" label="price" width="150" />-->
<!--    <el-table-column prop="segmentList.segment[0].departDate" label="Outward Date" width="200" />-->
<!--    <el-table-column prop="segmentList.segment[0].arriveDate" label="Return Date" width="200" />-->
<!--&lt;!&ndash;    <el-table-column prop="city" label="City" width="320" />&ndash;&gt;-->
<!--&lt;!&ndash;    <el-table-column prop="address" label="Address" width="600" />&ndash;&gt;-->
<!--&lt;!&ndash;    <el-table-column prop="zip" label="Zip" width="120" />&ndash;&gt;-->
<!--  </el-table>-->

  <div>
    <el-button type="primary" @click="routerGet">router get id</el-button>
    <el-button type="primary" @click="CheckRoutingCmd">Check Routing Cmd</el-button>
    <el-button type="primary" @click="parseXml">test mock</el-button>
    <el-button type="primary" @click="testMitt">Test mitt</el-button>

  </div>

  <div>
    <Group></Group>
  </div>

</template>


<script setup lang="ts">
import Group from "./Group.vue"
import {reactive, getCurrentInstance} from "vue";
import {ref, onMounted} from "vue"
import {useRoute} from "vue-router"
import {CrCommandList} from "../type/CheckRouting"

import {
  CacheInfo,
  Origin,
  Outward, OutwardList,
  PassengerPriceList,
  Price,
  Segment,
  SegmentList,
  TaxItem
} from "../type/CheckRoutingResp"

import axios from 'axios';
import builder from 'xmlbuilder';

const instance = getCurrentInstance()

const testMitt = ()=>{
  console.log("enter test mitt")

  instance?.proxy?.$Bus.emit("zhangxuhui","mitt")

}



let outwardList = reactive<OutwardList>({})


onMounted(() => {
  console.log("enter on mountdd");
  routerGet();
})

let routingId = ref<string>("")

let CrCommandList = reactive<CrCommandList>({
  CommandList: {
    CheckRouting: {
      XmlLoginId: "HJHH3K9HTYHJ45T0",
      LoginId: "HJHH3K9HTYHJ45T0",
      RoutingId: ""
    }
  }
})

const route = useRoute()

const CheckRoutingCmd = async () => {
  CrCommandList.CommandList.CheckRouting.RoutingId = routingId.value
  let a = builder.create(CrCommandList).end({pretty: false})
  console.log(a);

  let response = await axios.post("/api", a, {
    headers: {'Content-Type': 'text/xml'}
  })

  console.log(response.data);

}

const routerGet = () => {
  console.log(route.query);
  let a = route.query.id;
  console.log(a);

  if (typeof a === "string") {
    routingId.value = a
  }

}



const parseXml = async (param?: string) => {

  const resp = await axios.get('/checkRouting')
  let ckXml = resp.data.data.data
  let xmlDom = new DOMParser().parseFromString(ckXml, "text/html");
  let groupList = xmlDom.getElementsByTagName("Group");

  for (let i = 0; i < groupList.length; i++) {
    let group = groupList.item(i);
    let groupId = group.getElementsByTagName("Id").item(0).textContent;
    let outwardListXml = group.getElementsByTagName("OutwardList").item(0).getElementsByTagName("Outward")
    let returnList = group.getElementsByTagName("ReturnList").item(0).getElementsByTagName("Return")
    let outwards = extractOutwardList(outwardListXml);
    outwardList.outward = outwards
  }
}

const extractOutwardList = (element: HTMLCollectionOf<Element>): Array<Outward> => {
  let list = new Array<Outward>()

  for (let i = 0; i < element.length; i++) {
    let ele = element.item(i);

    let id = ele.getElementsByTagName("Id").item(0).textContent;
    let cacheInfo = ele.getElementsByTagName("CacheInfo");
    let price = ele.getElementsByTagName("Price");
    let Duration = ele.getElementsByTagName("Duration").item(0).textContent
    let SegmentList = ele.getElementsByTagName("SegmentList");

    let res: Outward = {
      id: id,
      cacheInfo: extractCacheInfo(cacheInfo),
      price: extractPrice(price),
      duration: Duration,
      segmentList: extractSegList(SegmentList)
    }

    list.push(res)

  }
  return list;
}

const extractSegList = (segList: HTMLCollectionOf<Element>): SegmentList => {
  let list = Array<Segment>()
  let segs = segList.item(0).getElementsByTagName("Segment");

  for (let i = 0; i < segs.length; i++) {
    let seg = segs.item(i);
    let originType = seg.getElementsByTagName("Origin").item(0).getElementsByTagName("Type").item(0).textContent;
    let originCode = seg.getElementsByTagName("Origin").item(0).getElementsByTagName("Code").item(0).textContent;
    let destType = seg.getElementsByTagName("Destination").item(0).getElementsByTagName("Type").item(0).textContent;
    let destCode = seg.getElementsByTagName("Destination").item(0).getElementsByTagName("Code").item(0).textContent;
    let departDate = seg.getElementsByTagName("DepartDate").item(0).textContent;
    let arriveDate = seg.getElementsByTagName("ArriveDate").item(0).textContent;
    let duration = seg.getElementsByTagName("Duration").item(0).textContent;

    let tfOpName = seg.getElementsByTagName("TfOperator").item(0).getElementsByTagName("Name").item(0).textContent;
    let tfOpCode = seg.getElementsByTagName("TfOperator").item(0).getElementsByTagName("Code").item(0).textContent;
    let tfVendorName = seg.getElementsByTagName("TfVendingOperator").item(0).getElementsByTagName("Name").item(0).textContent;
    let tfVendorCode = seg.getElementsByTagName("TfVendingOperator").item(0).getElementsByTagName("Code").item(0).textContent;
    let OpName = seg.getElementsByTagName("Operator").item(0).getElementsByTagName("Name").item(0).textContent;
    let OpCode = seg.getElementsByTagName("Operator").item(0).getElementsByTagName("Code").item(0).textContent;
    let vendorName = seg.getElementsByTagName("VendingOperator").item(0).getElementsByTagName("Name").item(0).textContent;
    let vendorCode = seg.getElementsByTagName("VendingOperator").item(0).getElementsByTagName("Code").item(0).textContent;

    let flightCode = seg.getElementsByTagName("FlightId").item(0).getElementsByTagName("Code").item(0).textContent;
    let flightNumber = seg.getElementsByTagName("FlightId").item(0).getElementsByTagName("Number").item(0).textContent;

    let TfClass = seg.getElementsByTagName("TfClass").item(0).textContent;
    let SupplierClass = seg.getElementsByTagName("SupplierClass").item(0).textContent;
    let SupplierClassDescription = seg.getElementsByTagName("SupplierClassDescription").item(0).textContent;
    let SupplierFareBasisCode = seg.getElementsByTagName("SupplierFareBasisCode").item(0).textContent;
    let SupplierRBDCode = seg.getElementsByTagName("SupplierRBDCode").item(0).textContent;
    let AircraftName = seg.getElementsByTagName("AircraftName").item(0).textContent;
    let AircraftCode = seg.getElementsByTagName("AircraftCode").item(0).textContent;
    let SegmentMayEndWithAStop = seg.getElementsByTagName("SegmentMayEndWithAStop").item(0).textContent;
    let res: Segment = {
      origin: {
        type: originType,
        code: originCode
      },
      destination: {
        type: destType,
        code: destCode
      },
      departDate: departDate,
      arriveDate: arriveDate,
      duration: duration,
      tfoperator: {
        name: tfOpName,
        code: tfOpCode
      },
      tfVendingoperator: {
        name: tfVendorName,
        code: tfVendorCode
      },
      operator: {
        name: OpName,
        code: OpCode
      },
      vendingOperator: {
        name: vendorName,
        code: vendorCode
      },
      flightId: {
        code: flightCode,
        number: flightNumber
      },
      travelClass: {
        tfClass: TfClass,
        supplierClass: SupplierClass,
        supplierClassDescription: SupplierClassDescription,
        supplierFareBasisCode: SupplierFareBasisCode,
        supplierRBDCode: SupplierRBDCode
      },
      aircraftType: {
        aircraftName: AircraftName,
        aircraftCode: AircraftCode
      },
      segmentMayEndWithAStop: SegmentMayEndWithAStop
    }
    list.push(res)
  }

  return {
    segment: list
  }
}

const extractCacheInfo = (cacheInfo: HTMLCollectionOf<Element>): CacheInfo => {
  let CacheDataAgeSeconds = cacheInfo.item(0).getElementsByTagName("CacheDataAgeSeconds").item(0).textContent;
  return {
    cacheDataAgeSeconds: CacheDataAgeSeconds
  }
}

const extractPrice = (price: HTMLCollectionOf<Element>): Price => {
  let Amount = price.item(0).getElementsByTagName("Amount").item(0).textContent
  let Currency = price.item(0).getElementsByTagName("Currency").item(0).textContent
  let PriceIncludesTax = price.item(0).getElementsByTagName("PriceIncludesTax").item(0).textContent
  let PassengerPriceList = price.item(0).getElementsByTagName("PassengerPriceList")

  return {
    amount: Amount,
    currency: Currency,
    priceIncludesTax: PriceIncludesTax,
    passengerPriceList: extractPaxPriceList(PassengerPriceList)
  }
}
const extractPaxPriceList = (paxPriceList: HTMLCollectionOf<Element>): PassengerPriceList => {
  let pax = paxPriceList.item(0);
  return {
    passengerPrice: {
      amount: pax.getElementsByTagName("Amount").item(0).textContent,
      currency: pax.getElementsByTagName("Currency").item(0).textContent,
      priceIncludesTax: pax.getElementsByTagName("PriceIncludesTax").item(0).textContent,
      taxItemList: {
        taxItem: extractTaxItem(pax.getElementsByTagName("TaxItem"))
      },
      age: pax.getElementsByTagName("Age").item(0).textContent,
    }
  }
}
const extractTaxItem = (taxItemList: HTMLCollectionOf<Element>): Array<TaxItem> => {
  let list = new Array<TaxItem>()
  for (let i = 0; i < taxItemList.length; i++) {
    let taxItem = taxItemList.item(0);
    let res: TaxItem = {
      name: taxItem.getElementsByTagName("Name").item(0).textContent,
      amount: taxItem.getElementsByTagName("Amount").item(0).textContent,
      currency: taxItem.getElementsByTagName("Currency").item(0).textContent
    }
    list.push(res)
  }
  return list
}
</script>
<style scoped>
.w-200 {
  width: 200px
}

.m-2 {
  margin: 2px
}
</style>
