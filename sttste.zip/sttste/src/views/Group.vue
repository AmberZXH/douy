<!--<template>-->

<!--  <div>-->
<!--    <h1>this is group</h1>-->
<!--    <div>{{ mittValue }}</div>-->
<!--    <button>Get Mitt value</button>-->

<!--    <div class="flex justify-between items-center flex-wrap">-->
<!--      <div-->
<!--          :key="i"-->
<!--          class="flex flex-col justify-center items-center"-->
<!--          m="auto"-->
<!--          w="46"-->
<!--      >-->
<!--        <div-->
<!--            class="inline-flex"-->
<!--            h="30"-->
<!--            w="30"-->
<!--            m="2"-->
<!--            :style="{-->
<!--          boxShadow: '&#45;&#45;el-box-shadow-dark',-->
<!--        }"-->
<!--        ></div>-->
<!--      </div>-->
<!--    </div>-->
<!--  </div>-->

<!--</template>-->

<!--<script setup lang='ts'>-->
<!--import {ref, getCurrentInstance} from "vue";-->

<!--const instance = getCurrentInstance()-->

<!--let mittValue = ref("")-->

<!--instance?.proxy?.$Bus.on("zhangxuhui", (val) => {-->
<!--  console.log("enter call bak")-->
<!--  console.log(val);-->
<!--  mittValue.value = val-->
<!--})-->


<!--</script>-->
<!--<style scoped>-->
<!--.zxh {-->
<!--  height: 200px;-->
<!--  width: 200px;-->
<!--  display: flex;-->
<!--  background: hotpink;-->
<!--  align-items: center;-->
<!--  boxShadow: &#45;&#45;el-box-shadow-dark;-->
<!--}-->
<!--</style>-->

<template>
  <div class="flex justify-between items-center flex-wrap">
    <div
        v-for="(shadow, i) in shadowGroup"
        :key="i"
        class="flex flex-col justify-center items-center"
        m="auto"
        w="46"
    >
      <div
          class="inline-flex"
          h="30"
          w="30"
          m="2"
          :style="{
          boxShadow: `var(${getCssVarName(shadow.type)})`,
        }"
      />
      <span p="y-4" class="demo-shadow-text" text="sm">
        {{ shadow.name }}
      </span>
      <code text="xs">
        {{ getCssVarName(shadow.type) }}
      </code>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue'

const shadowGroup = ref([
  {
    name: 'Basic Shadow',
    type: '',
  },
  {
    name: 'Light Shadow',
    type: 'light',
  },
  {
    name: 'Lighter Shadow',
    type: 'lighter',
  },
  {
    name: 'Dark Shadow',
    type: 'dark',
  },
])

const getCssVarName = (type: string) => {
  return `--el-box-shadow${type ? '-' : ''}${type}`
}
</script>


