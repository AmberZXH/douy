import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router'

const routes: Array<RouteRecordRaw> = [
    {
        path: "/emailDebug",
        name: "EmailDebug",
        component: () => import('../components/emailDebugInfo.vue'),
        meta: {
            keepAlive: true,
        }
    },
    {
        path: "/",
        name: "Gpt",
        component: () => import('../components/gpt.vue'),
        meta: {
            keepAlive: true,
        }
    },
    {
        path: "/startRouting",
        name: "StartRouting",
        component: () => import("../components/StartRouting.vue"),
        meta: {
            keepAlive: true,
        }
    },
    {
        path: "/checkRouting",
        name: "CheckRouting",
        component: () => import("../views/CheckRouting.vue"),
        meta: {
            keepAlive: true,
        }
    }
]


const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router
