<template>
  <div>
    <div>nihao</div>
    <div>
      <router-link to="/">gpt</router-link><br>
      <router-link to="/emailDebug">emialDebug</router-link>
    </div>
    <div>
      <router-view></router-view>
    </div>
  </div>
</template>


<script setup lang="ts">

</script>
