<template>
  <div>Test router</div>
</template>
<script setup lang='ts'>
</script>

<style scoped>

</style>

