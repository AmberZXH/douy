<template>
  <div>

    <input type="text" v-model="supplierName">
    <button @click="getEmailDebugInfoCmd(supplierName)">Get Email Debug Settings</button>
  </div>
  <div>
    <table class="styled-table">
      <thead>
      <tr>
        <th>Name</th>
        <th>Level</th>
        <th>Recipient</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="entry in entries" :key="entry.name">
        <td>{{ entry.name }}</td>
        <td>{{ entry.level }}</td>
        <td>{{ entry.recipient }}</td>
      </tr>
      </tbody>
    </table>
    <!-- <button @click="test">Test</button> -->
  </div>
</template>


<script setup lang='ts'>
import {ref} from 'vue';
import {getEmailDebugInfo} from "../api/c5/commands"

let supplierName = ref<string>()

type EmailModel = {
  name: string
  level: string
  recipient: string
}


let entries = ref(new Array<EmailModel>())

const getEmailDebugInfoCmd = async (supplierNameRef:string) => {
  console.log(supplierName.value)
  entries.value = []
  // let xmlStr = await getEmailDebugInfo(supplierNameRef);
  let xmlStr = "<CommandList><GetAllDebugLoggerActionmillis=\"12\"><LoginId>HJHH3K9HTYHJ45T0</LoginId><Entries><Entry><Name>engine.webspider.plane.airtransat.AirTransatBooking</Name><Level>WARNING</Level><Action><Mail><Recipients><Recipient>bsm@travelfusion.com</Recipient></Recipients><IncludeLoggerInfo>true</IncludeLoggerInfo></Mail></Action></Entry><Entry><Name>engine.webspider.plane.airtransat.AirTransatDetails</Name><Level>ERROR</Level><Action><Mail><Recipients><Recipient>kyrier.zhang@travelfusion.com</Recipient></Recipients><IncludeLoggerInfo>true</IncludeLoggerInfo></Mail></Action><Filters><Filtername=\"*Budget*\"/></Filters></Entry><Entry><Name>engine.webspider.plane.airtransat.AirTransatCancel</Name><Level>WARNING</Level><Action><Mail><Recipients><Recipient>kevin.wang@travelfusion.com</Recipient><Recipient>bsm@travelfusion.com</Recipient></Recipients><IncludeLoggerInfo>true</IncludeLoggerInfo></Mail></Action></Entry><Entry><Name>engine.webspider.plane.airtransat.AirTransatTerms</Name><Level>ERROR</Level><Action><Mail><Recipients><Recipient>kevin.wang@travelfusion.com</Recipient></Recipients><IncludeLoggerInfo>true</IncludeLoggerInfo></Mail></Action><Filters><Filtername=\"*Therehasbeenanerrorinthebookingprocess*\"/></Filters></Entry><Entry><Name>engine.webspider.plane.airtransat.AirTransatBookingChangeBooking</Name><Level>WARNING</Level><Action><Mail><Recipients><Recipient>bsm@travelfusion.com</Recipient><Recipient>kevin.wang@travelfusion.com</Recipient></Recipients><IncludeLoggerInfo>true</IncludeLoggerInfo></Mail></Action></Entry></Entries></GetAllDebugLoggerAction><GeneralInfoItemList><GeneralInfoItem><Name>ServerAddress</Name><Value>10.60.140.102</Value></GeneralInfoItem><GeneralInfoItem><Name>ClientAddress</Name><Value>180.169.129.148</Value></GeneralInfoItem><GeneralInfoItem><Name>StartTime</Name><Value>04/07/23-01:47:54</Value></GeneralInfoItem><GeneralInfoItem><Name>EndTime</Name><Value>04/07/23-01:47:54</Value></GeneralInfoItem></GeneralInfoItemList></CommandList>"
  // console.log(xmlStr);
  let domParser = new DOMParser();
  let xmlDoc = domParser.parseFromString(xmlStr, "text/html");
  let xmlEntries = xmlDoc.getElementsByTagName("Entry");

  for (let i = 0; i < xmlEntries.length; i++) {
    let name = xmlEntries.item(i)?.getElementsByTagName("Name").item(0)?.textContent.replace(/.*\.(\w+)$/, "$1");
    let level = xmlEntries.item(i)?.getElementsByTagName("Level").item(0)?.textContent;
    let recipient = xmlEntries.item(i)?.getElementsByTagName("Recipient").item(0)?.textContent;
    entries.value.push({
      name: name as string,
      level: level as string,
      recipient: recipient as string
    });
  }
}

</script>
<style scoped>
.styled-table {
  width: 100%;
  border-collapse: collapse;
}

.styled-table th,
.styled-table td {
  border: 1px solid #ddd;
  padding: 8px;
}

.styled-table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}

.styled-table tr:nth-child(even) {
  background-color: #f2f2f2;
}

.styled-table tr:hover {
  background-color: #ddd;
}
</style>
