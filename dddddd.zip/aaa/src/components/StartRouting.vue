<template>
  <el-form v-model="srForm"
           label-position="left"
           label-width = "60px"
  >
    <!--    supplier row -->
    <el-form-item label="supplier" >
      <el-col :span="6">
          <el-input v-model="srForm.supplier" class="w-50 m-2" size="large" placeholder="Please Input" />
      </el-col>
      <el-col :span="1">
      </el-col>
      <el-col :span="6">
        <el-date-picker
            v-model="outwardDate"
            type="date"
            placeholder="Pick a day"
            :size="size"
            format="DD/MM/YYYY"
        />
      </el-col>
      <el-col :span="1">
        <div>-</div>
      </el-col>
      <el-col :span="6">
        <el-date-picker
            v-model="returnDate"
            type="date"
            placeholder="Pick a day"
            :disabled-date="disabledDate"
            :shortcuts="shortcuts"
            :size="size"
            format="DD/MM/YYYY"
        />
      </el-col>
    </el-form-item>


    <!--    first row-->
    <el-form-item label="origin">
      <el-col :span="6">
          <el-input v-model="srForm.origin" style= "width:100px;" class="w-row-1 m-2" size="large" placeholder="Please Input" />
      </el-col>
    </el-form-item>

    <!--second row-->
      <el-form-item label="dest">
        <el-col :span="6">
        <el-input v-model="srForm.dest" style= "width:100px;" size="large" placeholder="Please Input" />
        </el-col>
      </el-form-item>
  </el-form>

  <el-row :gutter="20">
    <el-col :span="12">
      <el-form-item label="routing ID">
        <el-input v-model="routingId" class="w-200 m-2" size="large" />
      </el-form-item>
    </el-col>
  </el-row>

  <div>
    <el-button type="primary" @click="SRcmd">Start Routing</el-button>
  </div>
</template>

<script setup lang='ts'>
import axios from 'axios';
import builder from 'xmlbuilder';
import { ref, reactive } from "vue"
import { StartRoutingType } from "../type/StartRoutingType"
import { formatDate } from "../utils/formatter/index"
import { useRouter } from 'vue-router'
const route = useRouter()
let routingId = ref<string>("")

let flyTime = ref<[Date, Date]>([
  new Date(),
  new Date()
])

let outwardDate= ref<Date>(new Date());
let returnDate= ref<Date>(new Date());

const SRcmd = async () => {
  let response = await axios.post('/api', createXML(), {
    headers: { 'Content-Type': 'text/xml' },
  });
  let domParser = new DOMParser();
  let xmlDoc = domParser.parseFromString(response.data, "text/html");
  let routeId = xmlDoc.getElementsByTagName("RoutingId");
  routingId.value = routeId.item(0)?.textContent;

  await route.push({
    name: "CheckRouting",
    query: {
      id: routingId.value
    }
  })
}

let srForm: StartRoutingType = reactive<StartRoutingType>({
  dest: "YYZ",
  origin: "YUL",
  supplier: "airtransat"
});

const createXML = () => {
  return builder.create({
    CommandList: {
      StartRouting: {
        XmlLoginId: "HJHH3K9HTYHJ45T0",
        LoginId: "HJHH3K9HTYHJ45T0",
        Mode: "plane",
        Origin: {
          Descriptor: srForm.origin,
          Type: "airportcode",
          Radius: 1000,
        },
        Destination: {
          Descriptor: srForm.dest,
          Type: "airportcode",
          Radius: 1000,
        },
        OutwardDates: {
          DateOfSearch: formatDate(outwardDate.value),
        },
        ReturnDates:{
          DateOfSearch: formatDate(returnDate.value)
        },
        MaxChanges: 8,
        MaxHops: 8,
        SupplierList: {
          Supplier: srForm.supplier,
        },
        Timeout: 50,
        TravelClass: "Economy With Restrictions",
        TravellerList: {
          Traveller: [
            { Age: 30 }
          ],
        },
        IncrementalResults: "true",
        BookingProfile: {
          CustomSupplierParameterList: {
            CustomSupplierParameter: {
              Name: "IncludeStructuredFeatures",
              Value: "y",
            },
          },
        },
      },
    },
  }).end({ pretty: false });
}

</script>

<style scoped>
.el-row {
  margin-bottom: 20px;
}

.el-row:last-child {
  margin-bottom: 0;
}

.el-col {
  border-radius: 4px;
}

.w-50 {
  width: 100%
}

.w-200 {
  width: 200px
}


.m-2 {
  margin: 2px
}
</style>

