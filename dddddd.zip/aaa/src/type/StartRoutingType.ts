export interface Origin {
  descriptor: string;
  type: string;
  radius: string;
}

export interface Destination {
  descriptor: string;
  type: string;
  radius: string;
}

export interface OutwardDate {
  dateOfSearch: string;
}

export interface SupplierList {
  supplier: string;
}

export interface Traveller {
  age: string;
}

export interface TravellerList {
  traveller: Traveller;
}

export interface CustomSupplierParameter {
  name: string;
  value: string;
}

export interface CustomSupplierParameterList {
  customSupplierParameter: CustomSupplierParameter;
}

export interface BookingProfile {
  customSupplierParameterList: CustomSupplierParameterList;
}

export interface StartRouting {
  xmlloginId: string;
  loginId: string;
  mode: string;
  origin: Origin;
  destination: Destination;
  outwardDates: OutwardDate;
  maxChanges: string;
  maxHops: string;
  supplierList: SupplierList;
  timeout: string;
  travelClass: string;
  travellerList: TravellerList;
  incrementalResults: string;
  bookingProfile: BookingProfile;
}

export interface CommandList {
  startRouting: StartRouting;
}

export interface RootObject {
  commandList: CommandList;
}
