

type gptRspModel = {
    id: string
    object: string
    created: number
    model: string
    choices: Array<{
        index: number
        message: {
            role: string
            content: string
        }
        finish_reason: string
    }>
    usage: {
        prompt_tokens: number
        completion_tokens: number
        total_tokens: number
    }
};

type gptImageModel = {
    created: number
    data:Array<{
        url:string
    }>
}


const toEnglishPrompt:string = "I want you to act as an English translator, spelling corrector and improver. I will speak to you in any language and you will detect the language, translate it and answer in the corrected and improved version of my text, in English. I want you to replace my simplified A0-level words and sentences with more beautiful and elegant, upper level English words and sentences. Keep the meaning same, but make them more literary. I want you to only reply the correction, the improvements and nothing else, do not write explanations. My first sentence is: "
const toChinesePrompt:string = "Please help me translate the English into Chinese, please make sure the translation result is easy to undersand: "
const enhaceEnglishPrompt:string = "Polish the paragraph above to make it more formal, logical, and academic email communication: "
export async function toEnglish(content: string){
    return await gptChat(toEnglishPrompt,content)
}

export async function query(content: string){
    return await gptChat("",content)
}


export async function toChinese(content: string){
    return await gptChat(toChinesePrompt,content)
}

export async function enhanceEnglish(content: string){
    return await gptChat(enhaceEnglishPrompt,content)
}

export async function gptImage(prompt:string,num:number,picSize:string){
    
    try {
        const response = await fetch("https://api.openai.com/v1/images/generations", {
            method: "POST",
            body: JSON.stringify({
                prompt: prompt,
                n:num,
                size:picSize,
                response_format:"url"
            }),
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 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"
            }
        })
        if (!response.ok) {
            throw new Error(`Error! status: ${response.status}`);
        }
        const result = (await response.json()) as gptImageModel;
        let imageList:Array<string> = new Array<string>()
        result.data.forEach((e)=>{
            imageList.push(e.url)
        })
        
        return imageList
        
    } catch (error) {
        if (error instanceof Error) {
            console.log('error message: ', error.message);
            return error.message;
        } else {
            console.log('unexpected error: ', error);
            return 'An unexpected error occurred';
        }
    }


}

async function gptChat(prompt:string,content: string){
    try {
        const response = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            body: JSON.stringify({
                model: "gpt-3.5-turbo-16k-0613",
                messages: [{
                    role: "user",
                    content: prompt + content
                }]
            }),
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 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"
            }
        })

        if (!response.ok) {
            throw new Error(`Error! status: ${response.status}`);
        }
        const result = (await response.json()) as gptRspModel;

        // console.log('result is: ', JSON.stringify(result, null, 4));
        // console.log('result is: ', await response.text());
        // console.log("result is : ", result.choices[0].message.content);

        return result.choices[0].message.content
    
    } catch (error) {
        if (error instanceof Error) {
            console.log('error message: ', error.message);
            return error.message;
        } else {
            console.log('unexpected error: ', error);
            return 'An unexpected error occurred';
        }
    }
}

