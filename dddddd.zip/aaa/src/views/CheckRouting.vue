<template>
    <div>Check</div>
    <el-row :gutter="20">
        <el-col :span="12" class="h-50">
            <el-form-item label="routing ID">
                <el-input v-model="routingId" class="w-200 m-2" size="large" />
            </el-form-item>
        </el-col>
    </el-row>

    <div>
        <el-button type="primary" @click="getParam">get id</el-button>
        <el-button type="primary" @click="routerGet">router get id</el-button>
        <el-button type="primary" @click="sse">Test sse</el-button>
        </div>
</template>


<script setup lang="ts">
import { getCurrentInstance, ref } from "vue"
import { useRoute } from "vue-router"
import { testSse } from "../demo/test";

const sse = ()=>{
    testSse();
}


const instanct = getCurrentInstance()

let routingId = ref<string>("")

const getParam = () => {
    console.log("enter get param");

    instanct?.proxy?.$Bus.on("on-num", (param: string) => {
        console.log(param);
        routingId.value = param
    })
}

const route = useRoute()

const routerGet = ()=>{
    console.log(route.query);

    let a = route.query.id;
    console.log(a);
    routingId.value = a

}

</script>
<style scoped>
.w-200 {
    width: 200px
}
.m-2 {
    margin: 2px
}
</style>
