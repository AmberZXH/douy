export function formatDate(date:Date){
    let split = "/"
    let day:string = String(date.getDate());
    if(day.length == 1){
        day = "0" + day;
    }

    let month:string = String(date.getMonth() + 1);
    if(month.length == 1){
        month = "0" + month;
    }

    return day + split + month  + split + date.getFullYear() + "-00:00"
}
