<template>
  <!--  <div>-->
  <!--    <div>-->
  <!--      <router-link to="/">gpt</router-link>-->
  <!--      <router-link style="padding-left: 20px;" to="/emailDebug">Email Settings</router-link>-->
  <!--      <router-link  style="padding-left: 20px;" to="StartRouting">StartRouting</router-link>-->
  <!--    </div>-->
  <!--    <hr>-->
  <!--    <div>-->
  <!--      <router-view></router-view>-->
  <!--    </div>-->
  <!--  </div>-->
  <Layout></Layout>
</template>


<script setup lang="ts">
import  Layout  from "./Layout/index.vue"

</script>

<style scoped>
Layout {
  width: 100%;
  height: 100%;
}
</style>
