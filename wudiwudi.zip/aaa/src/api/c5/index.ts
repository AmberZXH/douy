import request, { http } from "../../utils/request"
// import type { AxiosPromise } from 'axios'


// const enum USER_API {
//   Login = '/user/login',
//   Userinfo = '/user/info',
// }

export function getEmailDebug(data:any){
    return http.post<string>("/", data)
}

// /**
//  * 登录
//  */
// export function login(data: string) {
//   return http.post<string>('/user/login', data);
// }

// // 使用原生 axios 实例进行请求
// export function loginRaw(data: LoginData): Promise<LoginRes> {
//   return request.post('/user/login', data);
// }

// /**
//  * 获取登录用户信息
//  */
// export function getUserInfo() {
//   return http.get<UserInfoRes>('/user/info')
// }