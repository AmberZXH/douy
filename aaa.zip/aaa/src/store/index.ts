import { defineStore } from "pinia"
import { CommandList } from "../type/StartRoutingType"
import { Names,LoginInfo,TravelClass} from "../enums"

export const StartRoutingStore = defineStore(Names.START_ROUTING, {

    state: () => {
        return {
            
        }
    },

    getters: {

    },

    actions: {

    }

})
