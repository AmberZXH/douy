export const enum Names {
    START_ROUTING = "Start-Routing"
}




export const enum LoginInfo {
      MONITOR = "HJHH3K9HTYHJ45T0",
      TF_WEBSITE = "TODO"

}