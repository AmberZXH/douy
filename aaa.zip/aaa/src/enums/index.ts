export const enum Names {
    START_ROUTING = "Start-Routing"
}




export const enum LoginInfo {
      MONITOR = "HJHH3K9HTYHJ45T0",
      TF_WEBSITE = "TODO"

}

export const enum TravelClass {
    ECONOMY_WITH_RESTRICTIONS="Economy With Restrictions"

}

export const enum AirPortType{
    AIRPORT_CODE = "airportcode"
}
