import {sendCmd} from "../c5/commands"

export const ListSuppliersApi = async (param : any) => {
    return await sendCmd(param)
}