

export const loginId:string = "HJHH3K9HTYHJ45T0"

export const assembleXml = (supplier?:string) :string=> {

    let param = isBlank(supplier)? "" : supplier
    return `<CommandList><GetAllDebugLoggerAction><XmlLoginId>${loginId}</XmlLoginId><LoginId>${loginId}</LoginId><NameRegex>engine.webspider.plane.${param}.*</NameRegex></GetAllDebugLoggerAction></CommandList>`
}

export async function getEmailDebugInfo(supplier?: string){

    let param = assembleXml(supplier)
    console.log(param);
    try {
        // fetch
        const response = await fetch("/api", {
            method: "POST",
            body: param,
            headers: {
                "Content-Type": "text/xml",
            }
        })

        if (!response.ok) {
            throw new Error(`Error! status: ${response.status}`);
        }

        return (await response.text())
    } catch (error) {
        if (error instanceof Error) {
            return error.message;
        } else {
            return 'An unexpected error occurred';
        }
    }
}

export function isBlank(value: any): boolean {
    return value === null || value == undefined || value === "";
}


export async function sendCmd(xmlCmd:string){

    try {
        // fetch
        const response = await fetch("/api", {
            method: "POST",
            body: xmlCmd,
            headers: {
                "Content-Type": "text/xml", 
            }
        })

        if (!response.ok) {
            throw new Error(`Error! status: ${response.status}`);
        }

        return (await response.text())
    } catch (error) {
        if (error instanceof Error) {
            return error.message;
        } else {
            return 'An unexpected error occurred';
        }
    }

}