import Mock from "mockjs"

import homeApi from "./mock/checkrouting"

Mock.mock("/checkRouting" , homeApi.getCheckRouting())



