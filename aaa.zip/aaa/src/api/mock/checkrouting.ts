import axios from 'axios';



export default {
    getCheckRouting: async() => {
        let a = await axios.get("../../../public/checkRouting-resp.xml")
        return {
            code: 200,
            data: {
                a
            }
        }
    }
}
