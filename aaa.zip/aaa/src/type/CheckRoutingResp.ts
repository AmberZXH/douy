export type DataItem = {

  id?: string,
  price?: string,
  currency?: string,
  duration?: string,
  segments?: Array<{
    originCode?: string,
    destCode?: string,
    departDate?: string,
    arriveDate?: string,
    duration?: string,
    tfOperator?: string,
    tfOperatorCode?: string,
    tfVendorOperator?: string,
    tfVendorOperatorCode?: string,
    operator?: string,
    operatorCode?: string,
    vendorOperator?: string,
    vendorOperatorCode?: string,
    flightCode?: string,
    flightNumber?: string,
    supplierClass?: string,
    supplierClassDesc?: string,
    supplierFareBasicCode?: string,
    supplierRBDCode?: string
    aircraftName?: string
    aircraftCode?: string
  }>

}

export type GroupList = {
  group?: Array<{
    id: string,
    outwardList: Array<DataItem>,
    returnList?: Array<DataItem>
  }>
}

export type PlaceInfo = {
  originCode?: string,
  destCode?: string,
  originName?: string,
  destName?: string,
  originType?: string,
  destType?: string,
  originCountry?: string,
  destCountry?: string,
}