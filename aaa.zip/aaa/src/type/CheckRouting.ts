export interface CheckRouting {
	XmlLoginId: string;
	LoginId: string;
	RoutingId: string;
}

export interface CommandList {
	CheckRouting: CheckRouting;
}

export interface CrCommandList {
	CommandList: CommandList;
}