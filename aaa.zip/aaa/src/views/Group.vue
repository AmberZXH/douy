<template>
  <el-card class="box-card">
    <template #header>
      <div class="card-header">
        <span class="outward-group-item" >Outward List</span>
      </div>
    </template>
    <div v-for="o in props.value.outwardList" :key="o" class="text item">
      <div v-for="seg in o.segments" class="seg-item">
        <el-row :gutter="20">
          <el-col :span="4">
            <el-text>{{ seg.originCode }} - {{ seg.destCode }}</el-text>
          </el-col>

          <el-col :span="4">
            <el-text>{{ seg.supplierClass }}</el-text>
          </el-col>
          
          <el-col :span="8">
            <el-text>{{ seg.departDate }} to {{ seg.arriveDate }}</el-text>
          </el-col>

          <el-col :span="4">
            <el-text>{{ seg.flightCode }}</el-text>
          </el-col>

          <el-col :span="4">
            <el-text class="mx-1 price-item" size="large">{{ o.price }} {{ o.currency }}</el-text>
          </el-col>
        </el-row>
      </div>
    </div>
  </el-card>

  <el-card class="box-card" v-show="props.value.returnList.length > 0">
    <template #header>
      <div class="card-header">
        <span>Return List</span>
      </div>
    </template>
    <div v-for="o in props.value.returnList" :key="o" class="text item">
      <div v-for="seg in o.segments" class="seg-item">
        <span>{{ seg.originCode }} - {{ seg.destCode }}</span>
        <span>{{ seg.departDate }} to {{ seg.arriveDate }}</span>
        <span>{{ o.price }} {{ o.currency }}</span>
      </div>
    </div>
  </el-card>

</template>

<script lang="ts" setup>

const props = defineProps(['value'])

const testTrf = () => {

  console.log("props type : ", typeof props);

  console.log(props);

  let a = props.value;

  console.log("props.value type : ", typeof a);
  console.log(a);


  console.log("props.value length : ", a.length);
}

</script>
<style scoped lang="less">
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.text {
  font-size: 14px;
}

.item {
  margin-bottom: 18px;
  border: 2px solid #4facfe;
  height: 60px;
  padding-bottom: 20px;
  background-image: linear-gradient(45deg, #ff9a9e 0%, #fad0c4 99%, #fad0c4 100%);
  box-shadow: var(--el-box-shadow-light);
  border-radius: 8px;
 


}

.seg-item {
  // border: 1px solid black;
  height: 50%;
  padding: 5px;
  // background-color: lightgray;
  // border-radius: 25px;
}

.box-card {
  width: 98%;
  margin: 20px auto 0px;
}
.price-item{
  display: flex;
  justify-content: flex-end;
}
.outward-group-item{
  font-family: Arial, Helvetica, sans-serif;
  font-size:20px
}



</style>
