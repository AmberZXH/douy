<template>
    <div>
        <el-button type="primary" @click="sendCmd">Primary</el-button>

        <el-button type="primary" @click="doSearch">Search</el-button>

        <el-input v-model="search" size="small" placeholder="Type to search" />
        
       
        <el-table :data="filterTableData" style="width: 100%">
            <el-table-column prop="name" label="Supplier" width="180" />
            <el-table-column prop="enabled" label="enabled" width="180" />
            <el-table-column prop="enabledForSearchAndReferral" label="SearchAndReferral" />
            <el-table-column prop="enabledForSearchAndBooking " label="SearchAndBooking" />
            <el-table-column prop="caching" label="caching" />
            <el-table-column prop="visible" label="visible" />
        </el-table>


        <div>
                woani
            <el-divider />
        </div>
        

        
    </div>
</template>
  
<script setup lang="ts">

import { ListSuppliersApi } from "../api/c5/tools"
import { reactive, ref ,computed } from "vue"
import { LoginInfo } from "../enums/index"
import builder from 'xmlbuilder';

const search = ref('')



type resp = {
    name?: string,
    enabled?: string,
    enabledForSearchAndReferral?: string,
    enabledForSearchAndBooking?: string,
    caching?: string,
    visible?: string
}

let ssss = reactive(new Array<resp>({
    name: "1",
    enabled: "1",
    enabledForSearchAndReferral: "1",
    enabledForSearchAndBooking: "1",
    caching: "1",
    visible: "1"
}))


const doSearch = () =>{
    
}

const filterTableData = computed(() =>
    ssss.filter(
    (data) =>
      !search.value ||
      data.name.toLowerCase().includes(search.value.toLowerCase())
  )
)

const sendCmd = async () => {

    let request = {
        CommandList: {
            ListSuppliers: {
                XmlLoginId: LoginInfo.MONITOR,
                LoginId: LoginInfo.MONITOR,
            }
        }
    }

    let param = builder.create(request).end({ pretty: false })
    let resp = await ListSuppliersApi(param)

    let dom = new DOMParser().parseFromString(resp, "text/html");

    Array.from(dom.getElementsByTagName("Supplier")).forEach(supplier => {

        let temp: resp = {
            name: supplier.getElementsByTagName("Name").item(0).textContent,
            enabled: supplier.getElementsByTagName("Enabled").item(0).textContent,
            enabledForSearchAndReferral: supplier.getElementsByTagName("EnabledForSearchAndReferral").item(0).textContent,
            enabledForSearchAndBooking: supplier.getElementsByTagName("EnabledForSearchAndBooking").item(0).textContent,
            caching: supplier.getElementsByTagName("Caching").item(0).textContent,
            visible: supplier.getElementsByTagName("Visible").item(0).textContent
        }
        
        ssss.push(temp)
    })

}




// const tableRowClassName = ({
//     row,
//     rowIndex,
// }: {
//     row: User
//     rowIndex: number
// }) => {
//     if (rowIndex === 1) {
//         return 'warning-row'
//     } else if (rowIndex === 3) {
//         return 'success-row'
//     }
//     return ''
// }
</script>

<style scoped>
.el-table .warning-row {
    --el-table-tr-bg-color: var(--el-color-warning-light-9);
}

.el-table .success-row {
    --el-table-tr-bg-color: var(--el-color-success-light-9);
}
</style>