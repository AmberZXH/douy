<template>
  <div>Check</div>
  <el-row :gutter="20">
    <el-col :span="12" class="h-50">
      <el-form-item label="routing ID">
        <el-input v-model="routingId" class="w-200 m-2" size="large" />
      </el-form-item>
    </el-col>
  </el-row>

  <div>
    <el-button type="primary" @click="routerGet">router get id</el-button>
    <el-button type="primary" @click="CheckRoutingCmd">Check Routing Cmd</el-button>
    <el-button type="primary" @click="parseXml">test mock</el-button>
    <el-button type="primary" @click="testMitt">Test mitt</el-button>
    <el-button type="primary" @click="readFile">Test readFile</el-button>

  </div>

  <div>
   
    <el-collapse v-model="activeNames" @change="handleChange">
    <div v-for="(i,index) in groupListRec.group">
        <el-collapse-item :title="'Group ' + index" :name="index">
          <Group :value="i"></Group>
        </el-collapse-item>
    </div>
  </el-collapse>

  </div>
</template>


<script setup lang="ts">
import Group from "./Group.vue"
import { reactive, getCurrentInstance,ref, onMounted } from "vue";
import { useRoute } from "vue-router"
import { CrCommandList } from "../type/CheckRouting"
import type {DataItem, GroupList} from "../type/CheckRoutingResp.ts"
import axios from 'axios';
import builder from 'xmlbuilder';
// const loading = ref(true)


const activeNames = ref(['1'])
let routingId = ref<string>("")
const handleChange = (val: string[]) => {

}

const readFile = async()=>{
  let a = await axios.get("../../public/checkRouting-resp.xml");
  console.log(a.data);
  return a
}

const instance = getCurrentInstance()
const testMitt = () => {
  instance?.proxy?.$Bus.emit("zhangxuhui", "mitt")
}

onMounted(() => {
  routerGet();
})



let CrCommandList = reactive<CrCommandList>({
  CommandList: {
    CheckRouting: {
      XmlLoginId: "HJHH3K9HTYHJ45T0",
      LoginId: "HJHH3K9HTYHJ45T0",
      RoutingId: ""
    }
  }
})


const route = useRoute()

const CheckRoutingCmd = async () => {
  CrCommandList.CommandList.CheckRouting.RoutingId = routingId.value
  let a = builder.create(CrCommandList).end({ pretty: false })
  console.log(a);

  let response = await axios.post("/api", a, {
    headers: { 'Content-Type': 'text/xml' }
  })

  console.log(response.data);

}

const routerGet = () => {
  let a = route.query.id;
  if (typeof a === "string") {
    routingId.value = a
  }

}



let groupListRec:GroupList = reactive({})

const parseXml = async () => {

  let resp = await axios.get("../../public/checkRouting-resp.xml")
  // console.log(resp.data);
  
  let ckXml = resp.data
  let xmlDom = new DOMParser().parseFromString(ckXml, "text/html");
  let groupList = xmlDom.getElementsByTagName("Group");

  groupListRec.group = new Array()
  for (let i = 0; i < groupList.length; i++) {
    
    let group = groupList.item(i);
    let groupId = group.getElementsByTagName("Id").item(0).textContent;
    let outwardListXml = group.getElementsByTagName("Outward")
    let returnListXml = group.getElementsByTagName("Return")
    let outwards = extractItems(outwardListXml);
    let returns = extractItems(returnListXml);
  
    groupListRec.group.push({
      id:groupId,
      outwardList:outwards,
      returnList:returns
    })
  }  
  
  console.log("Group size :" , groupListRec.group.length);
  
}

const extractItems = (element: HTMLCollectionOf<Element>): Array<DataItem> => {
  let res = new Array<DataItem>()
  for (let i = 0; i < element.length; i++) {
    let ele = element.item(i);
    let dataItem: DataItem = {}
    dataItem.id = ele.getElementsByTagName("Id").item(0).textContent;
    dataItem.price = ele.getElementsByTagName("Amount").item(0).textContent
    dataItem.currency = ele.getElementsByTagName("Currency").item(0).textContent
    dataItem.duration = ele.getElementsByTagName("Duration").item(0).textContent

    let segments = ele.getElementsByTagName("Segment")
    dataItem.segments = new Array();
    for (let k = 0; k < segments.length; k++) {
      let seg = segments.item(k);
      dataItem.segments.push({
        originCode: seg.getElementsByTagName("Origin").item(0).getElementsByTagName("Code").item(0).textContent,
        destCode: seg.getElementsByTagName("Destination").item(0).getElementsByTagName("Code").item(0).textContent,
        arriveDate: seg.getElementsByTagName("ArriveDate").item(0).textContent,
        departDate: seg.getElementsByTagName("DepartDate").item(0).textContent,
        duration: ele.getElementsByTagName("Duration").item(0).textContent,
        tfOperator: seg.getElementsByTagName("TfOperator").item(0).getElementsByTagName("Name").item(0).textContent,
        tfOperatorCode: seg.getElementsByTagName("TfOperator").item(0).getElementsByTagName("Code").item(0).textContent,
        tfVendorOperator: seg.getElementsByTagName("TfVendingOperator").item(0).getElementsByTagName("Name").item(0).textContent,
        tfVendorOperatorCode: seg.getElementsByTagName("TfVendingOperator").item(0).getElementsByTagName("Code").item(0).textContent,
        operator: seg.getElementsByTagName("Operator").item(0).getElementsByTagName("Name").item(0).textContent,
        operatorCode: seg.getElementsByTagName("Operator").item(0).getElementsByTagName("Code").item(0).textContent,
        vendorOperator: seg.getElementsByTagName("VendingOperator").item(0).getElementsByTagName("Name").item(0).textContent,
        vendorOperatorCode: seg.getElementsByTagName("VendingOperator").item(0).getElementsByTagName("Code").item(0).textContent,
        flightCode:seg.getElementsByTagName("FlightId").item(0).getElementsByTagName("Code").item(0).textContent,
        flightNumber:seg.getElementsByTagName("FlightId").item(0).getElementsByTagName("Number").item(0).textContent,
        supplierClass:seg.getElementsByTagName("TravelClass").item(0).getElementsByTagName("SupplierClass").item(0).textContent,
        supplierClassDesc:seg.getElementsByTagName("TravelClass").item(0).getElementsByTagName("SupplierClassDescription").item(0).textContent,
        supplierFareBasicCode:seg.getElementsByTagName("TravelClass").item(0).getElementsByTagName("SupplierFareBasisCode").item(0).textContent,
        supplierRBDCode:seg.getElementsByTagName("TravelClass").item(0).getElementsByTagName("SupplierRBDCode").item(0).textContent,
        aircraftName:seg.getElementsByTagName("AircraftType").item(0).getElementsByTagName("AircraftName").item(0).textContent,
        aircraftCode:seg.getElementsByTagName("AircraftType").item(0).getElementsByTagName("AircraftCode").item(0).textContent,
      })
    }
    res.push(dataItem)
  }

  return res;
}

</script>
<style scoped>
.w-200 {
  width: 200px
}

.m-2 {
  margin: 2px
}
</style>
