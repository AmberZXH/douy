import {createRouter, createWebHistory, RouteRecordRaw} from 'vue-router'

const routes:Array<RouteRecordRaw> = [
    {
        path: "/emailDebug",
        name: "EmailDebug",
        component: ()=> import('../components/emailDebugInfo.vue')
    },
    {
        path: "/",
        name: "Gpt",
        component: ()=> import('../components/gpt.vue')
    },
    {
        path: "/startRouting",
        name: "StartRouting",
        component: ()=> import("../components/StartRouting.vue")
    }
]
const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router
