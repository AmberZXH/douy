<template>
  <el-radio-group v-model="isCollapse" style="margin-bottom: 20px">
    <el-radio-button :label="false">expand</el-radio-button>
    <el-radio-button :label="true">collapse</el-radio-button>
  </el-radio-group>
  <el-menu
      default-active="2"
      class="el-menu-vertical-demo"
      :collapse="isCollapse"
      @open="handleOpen"
      @close="handleClose"
      :router="true"
  >
    <el-sub-menu index="1">
      <template #title>
        <span>工具</span>
      </template>
      <el-menu-item index="/">
        <template #title>翻译</template>
        <!--        <router-link :to="{name:Gpt}">翻译工具</router-link>-->
      </el-menu-item>
    </el-sub-menu>
    <el-sub-menu index="2">
      <template #title>C FIVE</template>
      <el-menu-item index="/startRouting">
        <template #title>Start Routing Cmd</template>
      </el-menu-item>

      <el-menu-item index="/checkRouting">
        <template #title>Check Routing Cmd</template>
      </el-menu-item>
      
      <el-menu-item index="/emailDebug">
        <template #title>Email Debug Cmd</template>
      </el-menu-item>

      <el-menu-item index="/listSupplier">
        <template #title>List Suppliers</template>
      </el-menu-item>

    </el-sub-menu>
  </el-menu>
</template>

<script setup lang='ts'>
import {ref} from 'vue'
import {useRouter} from 'vue-router'
const isCollapse = ref(false)
const router = useRouter()


</script>
<style scoped>
.el-menu-vertical-demo:not(.el-menu--collapse) {
  width: 200px;
  height: 100%;
}
</style>

