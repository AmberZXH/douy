<template>
  <el-form v-model="CommandList" label-position="left" label-width="60px">
    <!--    supplier row -->
    <el-form-item label="supplier">
      <el-col :span="6">
        <el-input v-model="CommandList.StartRouting.SupplierList.Supplier" class="w-50 m-2" size="large"
          placeholder="Please Input" />
      </el-col>
      <el-col :span="1">
      </el-col>
      <el-col :span="6">
        <el-date-picker v-model="outwardDate" type="date" placeholder="Pick a day" :size="size" format="DD/MM/YYYY" />
      </el-col>
      <el-col :span="1">
        <div>-</div>
      </el-col>
      <el-col :span="6">
        <el-date-picker v-model="returnDate" type="date" placeholder="Pick a day" :disabled-date="disabledDate"
          :shortcuts="shortcuts" :size="size" format="DD/MM/YYYY" />
      </el-col>
    </el-form-item>


    <!--    first row-->
    <el-form-item label="origin">
      <el-col :span="6">
        <el-input v-model="CommandList.StartRouting.Origin.Descriptor" style="width:100px;" class="w-row-1 m-2"
          size="large" placeholder="Please Input" />
      </el-col>
    </el-form-item>

    <!--second row-->
    <el-form-item label="dest">
      <el-col :span="6">
        <el-input v-model="CommandList.StartRouting.Destination.Descriptor" style="width:100px;" size="large"
          placeholder="Please Input" />
      </el-col>
    </el-form-item>
  </el-form>

  <el-row :gutter="20">
    <el-col :span="12">
      <el-form-item label="routing ID">
        <el-input v-model="routingId" class="w-200 m-2" size="large" />
      </el-form-item>
    </el-col>
  </el-row>

  <div>
    <el-button type="primary" @click="SRcmd">Start Routing</el-button>
    <el-button type="primary" @click="toCKPage">Go to Check Routing</el-button>
    <el-button type="primary" @click="dialogVisible = true">See Row XML</el-button>
  </div>



  <el-dialog v-model="dialogVisible" title="Tips" width="30%" :before-close="handleClose">
    <span>{{ respRow }}</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogVisible = false">Cancel</el-button>
        <el-button type="primary" @click="dialogVisible = false">
          Confirm
        </el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup lang='ts'>
import axios from 'axios';
import builder from 'xmlbuilder';
import { ref } from "vue"
import { CommandList } from "../type/StartRoutingType"
import { formatDate } from "../utils/formatter/index"
import { useRouter } from 'vue-router'
import { reactive } from 'vue';


import { ElMessageBox } from 'element-plus'

const dialogVisible = ref(false)
let respRow = ref<string>("")
const route = useRouter()
let routingId = ref<string>("")
const handleClose = (done: () => void) => {
  ElMessageBox.confirm('Are you sure to close this dialog?')
    .then(() => {
      done()
    })
    .catch(() => {
      // catch error
    })
}

let outwardDate = ref<Date>(new Date());
let returnDate = ref<Date>(new Date());

let CommandList: CommandList = reactive<CommandList>({
  StartRouting: {
    XmlLoginId: "HJHH3K9HTYHJ45T0",
    LoginId: "HJHH3K9HTYHJ45T0",
    Mode: "plane",
    Origin: {
      Descriptor: "YYZ",
      Type: "airportcode",
      Radius: "1000",
    },
    Destination: {
      Descriptor: "YUL",
      Type: "airportcode",
      Radius: "1000",
    },
    OutwardDates: {
      DateOfSearch: formatDate(outwardDate.value),
    },
    ReturnDates: {
      DateOfSearch: formatDate(returnDate.value),
    },
    MaxChanges: 8,
    MaxHops: 8,
    SupplierList: {
      Supplier: "airtransat"
    },
    Timeout: 50,
    TravelClass: "Economy With Restrictions",
    TravellerList: {
      Traveller: [
        { Age: 30 }
      ]
    },
    IncrementalResults: false,
    BookingProfile: {
      CustomSupplierParameterList: {
        CustomSupplierParameter: [
          {
            Name: "IncludeStructuredFeatures",
            Value: "y"
          }
        ]
      }
    }
  }
})

const SRcmd = async () => {
  let response = await axios.post('/api', createXML(), {
    headers: { 'Content-Type': 'text/xml' },
  });  
  respRow.value = response.data
  let domParser = new DOMParser();
  let xmlDoc = domParser.parseFromString(response.data, "text/html");
  let routeId = xmlDoc.getElementsByTagName("RoutingId");
  routingId.value = routeId.item(0)?.textContent;

}

const toCKPage = () => {
  route.push({
    name: "CheckRouting",
    query: {
      id: routingId.value
    }
  })
}

const createXML = () => {
  CommandList.StartRouting.OutwardDates.DateOfSearch = formatDate(outwardDate.value)
  CommandList.StartRouting.ReturnDates.DateOfSearch = formatDate(returnDate.value)
  return builder.create({ CommandList }).end({ pretty: false });
}

</script>

<style scoped>
.dialog-footer button:first-child {
  margin-right: 10px;
}

.el-row {
  margin-bottom: 20px;
}

.el-row:last-child {
  margin-bottom: 0;
}

.el-col {
  border-radius: 4px;
}

.w-50 {
  width: 100%
}

.w-200 {
  width: 200px
}


.m-2 {
  margin: 2px
}
</style>

