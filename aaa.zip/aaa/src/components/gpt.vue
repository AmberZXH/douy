<template>
  <div id="containor">

    <el-input
        v-model="promptText"
        :autosize="{ minRows: 2, maxRows: 4 }"
        type="textarea"
        placeholder="Please input"
    />
    <div style="margin-top:20px;">
      <el-button color="#626aef" @click="toChineseCmd()">翻译成中文</el-button>
      <el-button color="#626aef" @click="toEnglishCmd()">翻译成英文</el-button>
      <el-button color="#626aef" @click="enhanceEngCmd()">英语润色</el-button>
      <el-button color="#626aef" @click="askCmd()">提问</el-button>
    </div>

    <br>

    <el-input
        v-model="gptMsg"
        :autosize="{ minRows: 8, maxRows: 15 }"
        type="textarea"
        placeholder="Please input"
    />

    
    <br>

  </div>
</template>


<script setup lang="ts">
import {ref} from 'vue';
import {toEnglish, query, toChinese, enhanceEnglish} from "../api/gpt/index"

let promptText = ref<string>("")
let gptMsg = ref<string>("")

const toChineseCmd = async () => {
  gptMsg.value = await toChinese(promptText.value);
}

const toEnglishCmd = async () => {
  gptMsg.value = await toEnglish(promptText.value);
}
const enhanceEngCmd = async () => {
  gptMsg.value = await enhanceEnglish(promptText.value);
}
const askCmd = async () => {
  gptMsg.value = await query(promptText.value);
}


// async function generaeImage() {
//     let container = document.getElementById("imageContainer");
//     let imagePrompt = document.getElementById("imagePrompt").value;
//     let imageUrls = await gptImage(imagePrompt, 4, "256x256");
//     imageUrls.forEach(function (url) {
//         var image = document.createElement("img");
//         image.src = url;
//         container.appendChild(image);
//     });
// }

</script>

<style scoped>
.textClass {
  height: 250px;
  width: 800px;
}

.promptInputCls {
  width: 100%;
  height: 20px;
}

button {
  margin-left: 10px
}
</style>
