<template>
  <div>

    <input type="text" v-model="supplierName">
    <button @click="getEmailDebugInfoCmd(supplierName.toLowerCase())">Get Email Debug Settings</button>
  </div>
  <div>
    <table class="styled-table">
      <thead>
      <tr>
        <th>Name</th>
        <th>Level</th>
        <th>Recipient</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="entry in entries" :key="entry.name">
        <td>{{ entry.name }}</td>
        <td>{{ entry.level }}</td>
        <td>{{ entry.recipient }}</td>
      </tr>
      </tbody>
    </table>
    <!-- <button @click="test">Test</button> -->
  </div>
</template>


<script setup lang='ts'>
import {ref} from 'vue';
import {getEmailDebugInfo} from "../api/c5/commands"

let supplierName = ref<string>("")

type EmailModel = {
  name: string
  level: string
  recipient: string
}


let entries = ref(new Array<EmailModel>())

const getEmailDebugInfoCmd = async (supplierNameRef:string) => {

  entries.value = []
  let xmlStr = await getEmailDebugInfo(supplierNameRef);
  let domParser = new DOMParser();
  let xmlDoc = domParser.parseFromString(xmlStr, "text/html");
  let xmlEntries = xmlDoc.getElementsByTagName("Entry");

  for (let i = 0; i < xmlEntries.length; i++) {
    let name = xmlEntries.item(i)?.getElementsByTagName("Name").item(0)?.textContent?.replace(/.*\.(\w+)$/, "$1");
    let level = xmlEntries.item(i)?.getElementsByTagName("Level").item(0)?.textContent;
    let recipient = xmlEntries.item(i)?.getElementsByTagName("Recipient").item(0)?.textContent;
    entries.value.push({
      name: name as string,
      level: level as string,
      recipient: recipient as string
    });
  }
}

</script>
<style scoped>
.styled-table {
  width: 100%;
  border-collapse: collapse;
}

.styled-table th,
.styled-table td {
  border: 1px solid #ddd;
  padding: 8px;
}

.styled-table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}

.styled-table tr:nth-child(even) {
  background-color: #f2f2f2;
}

.styled-table tr:hover {
  background-color: #ddd;
}
</style>
