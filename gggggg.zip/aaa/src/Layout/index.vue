<template>
  <div class="common-layout">
    <el-container class="my-container">
      <el-aside width="200px">
        <Aside></Aside>
      </el-aside>
      <el-container>
        <el-header>Header</el-header>
        <el-main>
          <keep-alive>
            <router-view></router-view>
          </keep-alive>
        </el-main>
        <el-footer>Footer</el-footer>
      </el-container>
    </el-container>
  </div>
</template>

<script setup lang='ts'>
import Aside from "./Asides/index.vue"

</script>
<style scoped>
.common-layout{
  height: 100vh;
}
.my-container {
  height: 100%;

}
</style>

