import { createApp } from 'vue'
import App from './App.vue'
import router from "./router"
import ElementPlus  from 'element-plus'
import 'element-plus/dist/index.css'
import mitt from "mitt"
import "./api/mock"

const Mit = mitt()
declare module "vue"{
    export interface componentCustomProperties{
        $Bus: typeof Mit
    }
}

const app = createApp(App)
app.use(router)
app.use(ElementPlus)
app.config.globalProperties.$Bus = Mit

app.mount('#app');
