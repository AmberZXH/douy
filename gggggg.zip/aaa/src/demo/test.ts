import {Configuration, OpenAIApi} from "openai"

export  const testSse = async ()=>{
   
    const configuration = new Configuration({
      apiKey: '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',
    });
    const openai = new OpenAIApi(configuration);
    const response = await openai.retrieveModel("text-davinci-003");

    console.log(response);
}