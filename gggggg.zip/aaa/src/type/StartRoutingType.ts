export interface Origin {
  Descriptor?: string;
  Type?: string;
  Radius?: string;
}

export interface Destination {
  Descriptor?: string;
  Type?: string;
  Radius?: string;
}

export interface OutwardDate {
  DateOfSearch?: string;
}
export interface ReturnDate {
  DateOfSearch?: string;
}

export interface SupplierList {
  Supplier: string;
}

export interface Traveller {
  Age: number;
}

export interface TravellerList {
  Traveller: Traveller[];
}

export interface CustomSupplierParameter {
  Name: string;
  Value: string;
}

export interface CustomSupplierParameterList {
  CustomSupplierParameter: CustomSupplierParameter[];
}

export interface BookingProfile {
  CustomSupplierParameterList: CustomSupplierParameterList;
}

export interface StartRouting {
  XmlLoginId?: string;
  LoginId?: string;
  Mode?: string;
  Origin?: Origin;
  Destination?: Destination;
  OutwardDates?: OutwardDate;
  ReturnDates?: ReturnDate;
  MaxChanges?: number;
  MaxHops?: number;
  SupplierList?: SupplierList;
  Timeout?: number;
  TravelClass?: string;
  TravellerList?: TravellerList;
  IncrementalResults?: boolean;
  BookingProfile?: BookingProfile;
}

export interface CommandList {
  StartRouting: StartRouting;
}

export interface RootObject {
  CommandList: CommandList;
}
