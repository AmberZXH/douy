export interface Vendor {
    name: string;
    url: string;
}

export interface Origin {
    type: string;
    code: string;
}

export interface Destination {
    type: string;
    code: string;
}

export interface RequestedLocation {
    origin: Origin;
    destination: Destination;
}

export interface CacheInfo {
    cacheDataAgeSeconds: string;
}

export interface TaxItem {
    name: string;
    amount: string;
    currency: string;
}

export interface TaxItemList {
    taxItem: TaxItem[];
}

export interface PassengerPrice {
    amount: string;
    currency: string;
    priceIncludesTax: string;
    taxItemList: TaxItemList;
    age: string;
}

export interface PassengerPriceList {
    passengerPrice: PassengerPrice;
}

export interface Price {
    amount: string;
    currency: string;
    priceIncludesTax: string;
    passengerPriceList: PassengerPriceList;
}

export interface Origin {
    type: string;
    code: string;
}

export interface Destination {
    type: string;
    code: string;
}

export interface TfOperator {
    name: string;
    code: string;
}

export interface TfVendingOperator {
    name: string;
    code: string;
}

export interface Operator {
    name: string;
    code: string;
}

export interface VendingOperator {
    name: string;
    code: string;
}

export interface FlightId {
    code: string;
    number: string;
}

export interface TravelClas {
    tfClass: string;
    supplierClass: string;
    supplierClassDescription: string;
    supplierFareBasisCode: string;
    supplierRBDCode: string;
}

export interface AircraftType {
    aircraftName: string;
    aircraftCode: string;
}

export interface Segment {
    origin?: Origin;
    destination?: Destination;
    departDate?: string;
    arriveDate?: string;
    duration?: string;
    tfoperator?: TfOperator;
    tfVendingoperator?: TfVendingOperator;
    operator?: Operator;
    vendingOperator?: VendingOperator;
    flightId?: FlightId;
    travelClass?: TravelClas;
    aircraftType?: AircraftType;
    segmentMayEndWithAStop?: string;
}

export interface SegmentList {
    segment: Segment[];
}

export interface Outward {
    id: string;
    cacheInfo: CacheInfo;
    price: Price;
    duration: string;
    segmentList: SegmentList;
}

export interface OutwardList {
    outward?: Outward[];
}

export interface Group {
    id: string;
    outwardList: OutwardList;
}

export interface GroupList {
    group: Group;
}

export interface Condition {
    Type: string;
    Value: string;
}

export interface Option {
    Id: string;
    Currency: string;
    Value: string;
    condition: Condition[];
}

export interface Feature {
    Type: string;
    option: Option[];
}

export interface Feature {
    feature: Feature[];
}

export interface Router {
    supplier: string;
    vendor: Vendor;
    complete: string;
    requestedLocations: RequestedLocation;
    groupList: GroupList;
    features: Feature;
}

export interface RouterList {
    router: Router;
}

export interface Country {
    name: string;
    code: string;
}

export interface City {
    name: string;
    code: string;
}

export interface Airport {
    name: string;
    code: string;
}

export interface Location {
    id: string;
    name: string;
    country: Country;
    type: string;
    city: City;
    airport: Airport;
}

export interface City {
    name: string;
    code: string;
}

export interface Airport {
    name: string;
    code: string;
    city: City;
    distance: string;
}

export interface AirportList {
    airport: Airport;
}

export interface Origin {
    location: Location;
    airportList: AirportList;
}

export interface Country {
    name: string;
    code: string;
}

export interface City {
    name: string;
    code: string;
}

export interface Airport {
    name: string;
    code: string;
}

export interface Location {
    id: string;
    name: string;
    country: Country;
    type: string;
    city: City;
    airport: Airport;
}

export interface City {
    name: string;
    code: string;
}

export interface Airport {
    name: string;
    code: string;
    city: City;
    distance: string;
}

export interface AirportList {
    airport: Airport;
}

export interface Destination {
    location: Location;
    airportList: AirportList;
}

export interface Summary {
    origin: Origin;
    destination: Destination;
    distance: string;
    outwardDate: string;
}

export interface CheckRouting {
    millis: string;
    loginId: string;
    routingId: string;
    mode: string;
    routerList: RouterList;
    summary: Summary;
}

export interface GeneralInfoItem {
    name: string;
    value: string;
}

export interface GeneralInfoItemList {
    generalInfoItem: GeneralInfoItem[];
}

export interface CommandList {
    checkRouting: CheckRouting;
    generalInfoItemList: GeneralInfoItemList;
}

export interface RootObject {
    commandList: CommandList;
}
