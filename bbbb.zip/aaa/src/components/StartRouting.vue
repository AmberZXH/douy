<template>

  <el-form :model="srForm" >
    <!--    supplier row -->
    <el-row :gutter="20">
      <el-col :span="6">
        <el-form-item label="supplier">
          <el-input v-model="srForm.supplier" class="w-50 m-2" size="large" placeholder="Please Input"/>
        </el-form-item>
      </el-col>

      <el-col :span="12">
        <el-date-picker
            v-model="flyTime"
            type="daterange"
            range-separator="To"
            start-placeholder="Start date"
            end-placeholder="End date"
            format="DD/MM/YYYY"
        />
      </el-col>
    </el-row>

    <!--    first row-->
    <el-row :gutter="20">
      <el-col :span="6">
        <el-form-item label="origin">
          <el-input v-model="srForm.origin" class="w-50 m-2" size="large" placeholder="Please Input"/>
        </el-form-item>
      </el-col>
    </el-row>

<!--second row-->
    <el-row :gutter="20">
      <el-form-item label="dest">
        <el-input v-model="srForm.dest" class="w-50 m-2" size="large" placeholder="Please Input"/>
      </el-form-item>
    </el-row>
  </el-form>

  <div>
    <el-button type="primary" @click="test">Primary</el-button>
    <el-button type="primary" @click="sendHttp">sendHttp</el-button>
  </div>

</template>

<script setup lang='ts'>
import axios from 'axios';
import builder from 'xmlbuilder';
import {ref, reactive} from "vue"
import {StartRoutingType} from "../type/StartRoutingType"
import {formatDate} from "../utils/formatter/index"
let flyTime = ref<[Date, Date]>([
    new Date(),
    new Date()
])

const test =() => {
  let startDate = flyTime.value.at(0);

  console.log("Start Time ", startDate)
  console.log("End time ",flyTime.value.at(1))

  console.log(startDate.getFullYear(), startDate.getMonth(), startDate.getDate());
}
let srForm = reactive<StartRoutingType>({});

const xml = builder.create({
  CommandList: {
    StartRouting: {
      XmlLoginId: "HJHH3K9HTYHJ45T0",
      LoginId: "HJHH3K9HTYHJ45T0",
      Mode: "plane",
      Origin: {
        Descriptor: srForm.origin,
        Type: "airportcode",
        Radius: 1000,
      },
      Destination: {
        Descriptor: srForm.origin,
        Type: "airportcode",
        Radius: 1000,
      },
      OutwardDates: {
        DateOfSearch: formatDate(flyTime.value.at(0)),
      },
      // ReturnDates:{
      //   DateOfSearch: formatDate(flyTime.value.at(1))
      // },
      MaxChanges: 8,
      MaxHops: 8,
      SupplierList: {
        Supplier: srForm.supplier,
      },
      Timeout: 50,
      TravelClass: "Economy With Restrictions",
      TravellerList: {
        Traveller: [
          {Age: 30}
        ],
      },
      IncrementalResults: "true",
      BookingProfile: {
        CustomSupplierParameterList: {
          CustomSupplierParameter: {
            Name: "IncludeStructuredFeatures",
            Value: "y",
          },
        },
      },
    },
  },
}).end({pretty: false});



console.log(xml)
const sendHttp = async () => {
  let response = await axios.post('/api', xml, {
    headers: {'Content-Type': 'text/xml'},
  });
  console.log(response.data);
}

</script>

<style scoped>
.el-row {
  margin-bottom: 20px;
}

.el-row:last-child {
  margin-bottom: 0;
}

.el-col {
  border-radius: 4px;
}

.grid-content {
  border-radius: 4px;
  min-height: 36px;
  background-color: gray;
}

.w-50 {
  width: 100px
}

.m-2 {
  margin: 2px
}
</style>

