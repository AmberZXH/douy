export type StartRoutingType = {
    origin?:string
    dest?:string
    supplier?:string
}
